package application;
import java.io.File;
import javafx.application.Application;
import javafx.geometry.*;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.geometry.Pos;
import javafx.stage.Modality;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.VBox;
import javafx.scene.control.*;
import javafx.event.ActionEvent; 
import javafx.event.EventHandler;
import javafx.scene.image.*;
import java.io.FileInputStream;


class AlertBox {
	
	public static void display(String title, String msg)
	{
		Stage window = new Stage();
		window.initModality(Modality.APPLICATION_MODAL);
		window.setTitle("Alert Box");
		
		Label label = new Label();
		label.setText(msg);
		Button closebutton = new Button("close");
		closebutton.setOnAction(e -> window.close());
		
		VBox layout = new VBox(20);
		layout.getChildren().addAll(label,closebutton);
		layout.setAlignment(Pos.CENTER);
		
		Scene scene = new Scene(layout);
		window.setScene(scene);
		window.showAndWait();
	}
}

public class Main extends Application {

	Stage window;
	Scene scene1,scene2,scene3,scene4;
	static double i=0;

	@Override
	public void start(Stage primaryStage) throws Exception{
		
		VBox root = new VBox();
		window = primaryStage;
		window.setTitle("Box");
		Separator sep = new Separator();
	    sep.setHalignment(HPos.CENTER);
	   
		Button submit = new Button("Continue");
		
		submit.setOnAction(e -> window.setScene(scene3));
		GridPane.setConstraints(submit, 0, 9);
		GridPane grid = new GridPane();
		grid.setPadding(new Insets(10, 10, 10, 10));
		grid.setVgap(8);
		grid.setHgap(10);
		grid.setAlignment(Pos.CENTER);
		
		HBox hbox = new HBox();
		
		BackgroundFill background_fill = new BackgroundFill(Color.LIGHTBLUE, CornerRadii.EMPTY, Insets.EMPTY);
		BackgroundFill background_fill2 = new BackgroundFill(Color.WHITE, CornerRadii.EMPTY, Insets.EMPTY);
		Background background = new Background(background_fill);
		Background background2 = new Background(background_fill2);
		grid.setBackground(background);
		
		Label name = new Label("Username");
		GridPane.setConstraints(name, 0, 0);
		TextField nameInput = new TextField("Rishabh");
		GridPane.setConstraints(nameInput, 1, 0);
		Label pass = new Label("Password");
		GridPane.setConstraints(pass, 0, 1);
		PasswordField passInput = new PasswordField();
		passInput.setPromptText("Your password");
		GridPane.setConstraints(passInput, 1, 1);
		CheckBox cbox = new CheckBox("Tick to agree to terms and conditions");
		GridPane.setConstraints(cbox, 1, 2);
		Button button = new Button("Login");
		button.setOnAction(e -> buttonCheck(passInput, cbox));
		GridPane.setConstraints(button, 1, 3);
		
		FileInputStream fis=new FileInputStream("C:\\Users\\Asus\\OneDrive\\Desktop\\cu.jpg");
		Image im=new Image(fis);
		ImageView imv=new ImageView(im);
		imv.setFitHeight(100);
		imv.setFitWidth(100);
		imv.setTranslateX(115); 
	    imv.setTranslateY(-80);
	    
		grid.getChildren().addAll(imv, name, nameInput, pass, passInput, button, cbox);
		
		primaryStage.setTitle("Quiz Portal");

		Label labelfirst= new Label("What is 10 + 10?");
		Label labelresponse= new Label();

		VBox layout= new VBox(5);

		Button buttonx= new Button("Submit");
		Button prg= new Button("Check Progress");
		
		RadioButton radio1, radio2, radio3, radio4;
		radio1=new RadioButton("10");
		radio2= new RadioButton("30");
		radio3= new RadioButton("20");
		radio4= new RadioButton("40");

		ToggleGroup question1= new ToggleGroup();
		radio1.setToggleGroup(question1);
		radio2.setToggleGroup(question1);
		radio3.setToggleGroup(question1);
		radio4.setToggleGroup(question1); 
		
		ProgressBar progress = new ProgressBar();
		ProgressIndicator indicator = new ProgressIndicator(0);
		progress.setPrefSize(300, 30);
		GridPane.setConstraints(progress, 0, 7);
		GridPane.setConstraints(indicator, 1, 7);
		   
		EventHandler<ActionEvent> event = new EventHandler<ActionEvent>() { 
			public void handle(ActionEvent e) 
	            { 
	                i += 1; 
	                progress.setProgress(i); 
	                indicator.setProgress(i);
	            }
	        };
	     
	    prg.setOnAction(event); 
	        
	    buttonx.setOnAction(e ->{
			if (radio3.isSelected()){
			     labelresponse.setText("Correct answer: "+ radio3.getText());
			}
			else{
			       labelresponse.setText("Wrong answer");
			}           
		});
	        
	    Label pbar = new Label("Your quiz progress: ");
		pbar.setTextFill(Color.RED);
	    GridPane.setConstraints(pbar, 0, 6);
			
	    
	    GridPane.setConstraints(pbar, 0, 6);
			
		layout.getChildren().addAll(labelfirst, radio1, radio2, radio3, radio4, buttonx, labelresponse, pbar, progress, indicator, prg, submit);

		Scene scene5= new Scene(layout, 400, 250);
		primaryStage.setScene(scene5);

		primaryStage.show();
		
	    
	    Label h = new Label("Click on the link to download our app: ");
	    GridPane.setConstraints(h, 1, 4);
	    Hyperlink hp = new Hyperlink("https://play.google.com/store/apps/details?id=com.cuvale");
	    GridPane.setConstraints(hp, 1, 5);
		
	    Label fback = new Label("Kindly rate our portal: ");
	    fback.setTextFill(Color.BLUE);
		GridPane.setConstraints(fback, 1, 1); 
		
	    Slider slider = new Slider(0, 5, 0);
	    slider.setShowTickMarks(true);
	    slider.setShowTickLabels(true);
	    slider.setMajorTickUnit(0.25f);
	    slider.setBlockIncrement(0.1f);
	    GridPane.setConstraints(slider, 1, 2);
	    
	    Label h1 = new Label("Thank You for Visiting");
	    GridPane.setConstraints(h1, 1, 7);
	    Button cnt = new Button("Log Out");
	    GridPane.setConstraints(cnt, 1, 9);
		Button button1 = new Button("Upload");
		GridPane.setConstraints(button1, 1, 4);
		
		GridPane grid3 = new GridPane();
		grid3.setPadding(new Insets(10, 10, 10, 10));
		grid3.setVgap(8);
		grid3.setHgap(10);
		grid3.setAlignment(Pos.CENTER);
		grid3.setBackground(background2);
		
		root.getChildren().addAll(hbox,layout);
		grid3.getChildren().addAll(slider,fback,h,hp,h1,cnt);
		
		scene1 = new Scene(grid, 400, 400);
		window.setScene(scene1);
		window.show();
		scene2 = new Scene(root, 500, 400);
		scene3 = new Scene(grid3, 350, 350);
	}
	private void buttonCheck(TextField passInput, CheckBox cbox) {
		String pass = "Rishabh";
		if(pass.equals(passInput.getText())){
			if(cbox.isSelected()){
			System.out.println("Welcome!!");
			window.setScene(scene2);
			}
			else
				AlertBox.display("CheckBox", "Please tick the check box");
		}
		else{
			System.out.println("Wrong password");
			AlertBox.display("WrongPassword", "Please enter correct password");
		}
		
	}
	public static void main(String[] args){
		launch(args);
	}   
}
